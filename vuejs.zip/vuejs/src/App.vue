<script setup>
import { useRoute, useRouter } from 'vue-router'
import api from './api';


const route = useRoute();
const router = useRouter()

const logout = async () => {
  const token = localStorage.getItem('token')

  await api.post('/auth/logout', {}, { 'headers': { 'Authorization': "Bearer " + token } })
    .then((response) => {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      router.push({ name: 'logout' })
    }).catch((error) => {
      if (error.status === 401) {
        localStorage.removeItem('token')
        localStorage.removeItem('user')
        router.push({ name: 'logout' })
      }
    })

}

</script>


<template>

  <!-- Begin page -->
  <div id="wrapper" v-if="(['task.index', 'dashboard']).includes(route.name)">

    <!-- Topbar Start -->
    <div class="navbar-custom">
      <ul class="list-unstyled topnav-menu float-right mb-0">

        <li class="dropdown notification-list">
          <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#"
            role="button" aria-haspopup="false" aria-expanded="false">
            <span class="pro-user-name ml-1">
              Nik Patel <i class="mdi mdi-chevron-down"></i>
            </span>
          </a>
          <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
            <!-- item-->
            <div class="dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome !</h6>
            </div>

            <!-- item-->
            <a href="javascript:void(0);" class="dropdown-item notify-item">
              <i class="remixicon-account-circle-line"></i>
              <span>My Account</span>
            </a>


            <div class="dropdown-divider"></div>

            <!-- item-->
            <button type="button" @click="logout()" class="dropdown-item notify-item">
              <i class="remixicon-logout-box-line"></i>
              <span>Logout</span>
            </button>

          </div>
        </li>

      </ul>

      <!-- LOGO -->
      <div class="logo-box">
        <router-link :to="{ name: 'dashboard' }" class="logo text-center">
          <span class="logo-lg">
            <!-- <img src="assets\images\logo-light.png" alt="" height="20"> -->
            <span class="logo-lg-text-light">Todo List</span>
          </span>
        </router-link>
      </div>
    </div>
    <!-- end Topbar -->

    <!-- ========== Left Sidebar Start ========== -->
    <div class="left-side-menu">

      <div class="slimscroll-menu">

        <!--- Sidemenu -->
        <div id="sidebar-menu">

          <ul class="metismenu" id="side-menu">

            <li class="menu-title">Navigation</li>

            <li>
              <router-link :to="{ name: 'dashboard' }" class="waves-effect">
                <i class="remixicon-dashboard-line"></i>
                <span> Dashboards </span>
              </router-link>
            </li>

            <li>
              <router-link :to="{ name: 'task.index' }" class="waves-effect">
                <i class="remixicon-edit-2-line"></i>
                <span> tasks </span>
              </router-link>
            </li>

          </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

      </div>
      <!-- Sidebar -left -->

    </div>
    <!-- Left Sidebar End -->

    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->

    <router-view></router-view>


    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->


  </div>

  <!-- END wrapper -->

  <div v-if="(['login', 'logout', 'register']).includes(route.name)">
    <router-view></router-view>
  </div>

</template>