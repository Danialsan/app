import { createRouter, createWebHistory } from "vue-router";

const routes = [
    {
        path: '/',
        redirect: '/login'
    },
    {
        path: '/login',
        name: 'login',
        component: () => import('../views/pages-login.vue'),
        meta: { guest: true }
    },
    {
        path: '/register',
        name: 'register',
        component: () => import('../views/pages-register.vue'),
        meta: { guest: true }
    },
    {
        path: '/logout',
        name: 'logout',
        component: () => import('../views/pages-logout.vue'),
        meta: { guest: true }
    },
    {
        path: '/task',
        name: 'task.index',
        component: () => import('../views/apps-kanbanboard.vue'),
        meta: { auth: true }
    },
    {
        path: '/dashboard',
        name: 'dashboard',
        component: () => import('../views/pages-starter.vue'),
        meta: { auth: true }
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes
})

router.beforeEach((to, from, next) => {
    const token = localStorage.getItem('token')
    if (to.meta.guest && token) {
        next({ name: "dashboard" })
    } else if (to.meta.auth && !token) {
        next({ name: 'login' })
    } else {
        next()
    }
})

export default router