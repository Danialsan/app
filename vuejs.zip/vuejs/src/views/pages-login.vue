﻿<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import api from '../api'

const email = ref('')
const password = ref('')
const message = ref('')
const validation = ref([])

const router = useRouter()

const login = async () => {
    const data = {
        email: email.value,
        password: password.value
    }

    await api.post('auth/login', data)
        .then((response) => {
            console.log(response);
            localStorage.setItem('token', response.data.token)
            localStorage.setItem('user', JSON.stringify(response.data.user))
            router.push({ name: 'dashboard' })
        }).catch((error) => {
            console.log(error);
            if (error.status === 401) {
                message.value = error.response.data.message
            }
            if (error.status === 422) {
                validation.value = error.response.data.validation
            }
        })

}


</script>
<template>
    <div class="account-pages mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card">

                        <div class="card-body p-4">

                            <div class="text-center w-75 m-auto">
                                <router-link :to="{ name: 'login' }">
                                    <span>
                                        <h1 class="text-primary font-weight-bold">Sign in</h1>
                                    </span>
                                </router-link>
                                <p class="text-muted mb-4 mt-3">Enter your email address and password to access
                                    todo list.</p>
                            </div>

                            <form @submit.prevent="login()">

                                <div class="alert alert-danger" v-if="message">
                                    {{ message }}
                                </div>

                                <div class="form-group mb-3">
                                    <label for="emailaddress">Email address</label>
                                    <input class="form-control" type="email" id="emailaddress" required="required"
                                        v-model="email" placeholder="Enter your email">
                                    <div class="alert alert-danger mt-1" v-if="validation.email">
                                        {{ validation.email[0] }}
                                    </div>
                                </div>

                                <div class="form-group mb-3">
                                    <label for="password">Password</label>
                                    <input class="form-control" type="password" required="required" id="password"
                                        placeholder="Enter your password" v-model="password">
                                    <div class="alert alert-danger mt-1" v-if="validation.password">
                                        {{ validation.password[0] }}
                                    </div>
                                </div>

                                <div class="form-group mb-0 text-center">
                                    <button class="btn btn-primary btn-block" type="submit"> Log In </button>
                                </div>

                            </form>

                            <!-- <div class="text-center">
                                <h5 class="mt-3 text-muted">Sign in with</h5>
                                <ul class="social-list list-inline mt-3 mb-0">
                                    <li class="list-inline-item">
                                        <a href="javascript: void(0);"
                                            class="social-list-item border-primary text-primary"><i
                                                class="mdi mdi-facebook"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="javascript: void(0);"
                                            class="social-list-item border-danger text-danger"><i
                                                class="mdi mdi-google"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="javascript: void(0);" class="social-list-item border-info text-info"><i
                                                class="mdi mdi-twitter"></i></a>
                                    </li>
                                    <li class="list-inline-item">
                                        <a href="javascript: void(0);"
                                            class="social-list-item border-secondary text-secondary"><i
                                                class="mdi mdi-github-circle"></i></a>
                                    </li>
                                </ul>
                            </div> -->

                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->

                    <div class="row mt-3">
                        <div class="col-12 text-center">
                            <p class="text-muted">Don't have an account? <router-link :to="{ name: 'register' }"
                                    class="text-primary font-weight-medium ml-1">Sign Up</router-link></p>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- end col -->
            </div>
        </div>
    </div>


    <footer class="footer footer-alt">
        2025 &copy; Achmad Danel by Coderthemes
    </footer>



</template>