﻿<script setup>
import { onMounted, ref } from "vue";
import api from "../api";



const tasks = ref([])
const message = ref('')

const fetchData = async () => {
    const token = localStorage.getItem('token')

    await api.get('/tasks', { 'headers': { 'Authorization': "Bearer " + token } })
        .then((response) => {
            tasks.value = response.data.data
        }).catch((error) => {
            if (error.status === 404) {
                message.value = error.response.data.message
                console.log(error.response.data.message);

            }
        })
}

onMounted(() => {
    fetchData()
})

const name_task = ref('')
const description = ref('')
const priority = ref('')
const deadline = ref('')
const messageSuccess = ref('')
const validation = ref([])

const createTask = async () => {
    const token = localStorage.getItem('token')
    const data = {
        name_task: name_task.value,
        description: description.value,
        priority: priority.value,
        deadline: deadline.value,
    }

    await api.post('/tasks', data, { 'headers': { 'Authorization': "Bearer " + token } })
        .then((response) => {
            messageSuccess.value = response.data.message
        }).catch((error) => {
            if (error.status === 422) {
                validation.value = error.response.data.validation
            }
        })
}

const messageDone = ref('')

const isDone = async (id) => {

    const token = localStorage.getItem('token')

    const data = {
        is_done: true
    }

    await api.put(`/tasks/done/${id}`, data, { 'headers': { 'Authorization': "Bearer " + token } })
        .then((response) => {
            console.log(response);
            messageDone.value = response.data.message
        }).catch((error) => {
            console.log(error);

        })
}

const messagedelete = ref('')

const deleteTask = async (id) => {
    const confirmation = confirm('Are you sure want to delete this task?')

    if (confirmation) {
        const token = localStorage.getItem('token')
        await api.delete(`/tasks/${id}`, { 'headers': { 'Authorization': "Bearer " + token } })
            .then((response) => {
                messagedelete.value = response.data.message
                fetchData()
            }).catch((error) => {
                console.log(error);

            })
    } else {
        return fetchData()
    }

}

</script>

<template>

    <div class="content-page">
        <div class="content">

            <!-- Start Content-->
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><router-link :to="{ name: 'dashboard' }">Todo
                                            List</router-link></li>
                                    <li class="breadcrumb-item active">Tasks</li>
                                </ol>
                            </div>
                            <h4 class="page-title">Tasks</h4>
                        </div>
                    </div>
                </div>
                <!-- end page title -->


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card-box">
                            <!-- end dropdown -->
                            <div class="alert alert-success" v-if="messageDone">
                                {{ messageDone }}
                            </div>
                            <div class="alert alert-success" v-if="messagedelete">
                                {{ messagedelete }}
                            </div>
                            <h4 class="header-title">List task</h4>
                            <p class="sub-header">
                                Your awesome text goes here. Your awesome text goes here.
                            </p>
                            <ul v-if="message" class="sortable-list tasklist list-unstyled">
                                <h4>{{ message }}</h4>

                            </ul>
                            <ul v-else v-for="(data, index) in tasks" :key="index"
                                class="sortable-list tasklist list-unstyled mt-1" id="upcoming">

                                <li id="task1" class="task-low">

                                    <div class="dropdown float-right">
                                        <a href="#" class="dropdown-toggle arrow-none" data-toggle="dropdown"
                                            aria-expanded="false">
                                            <i class="mdi mdi-dots-vertical m-0 text-muted h3"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <button class="dropdown-item" @click="isDone(data.id)">Done</button>
                                            <a class="dropdown-item" href="#">Edit</a>
                                            <button class="dropdown-item" @click="deleteTask(data.id)">Delete</button>
                                        </div>
                                    </div>

                                    <h5 class="mt-0">
                                        <span class="text-dark">
                                            {{ data.name_task }}
                                        </span>
                                    </h5>

                                    <p>{{ data.description }}.</p>
                                    <div class="clearfix"></div>
                                    <div class="row">
                                        <div class="col">
                                            <div class="text-right">
                                                <p class="font-13 mt-2 mb-0"><i class="mdi mdi-calendar"></i> {{
                                                    data.deadline }}</p>
                                            </div>
                                        </div>
                                    </div>

                                </li>

                            </ul>
                            <button type="button" class="btn btn-primary btn-block mt-3 waves-effect waves-light"
                                data-toggle="modal" data-target="#taskCreateModal">
                                <i class="mdi mdi-plus-circle"></i> Add New
                            </button>
                        </div>
                    </div> <!-- end col -->

                    <!-- taskCreateModal  -->
                    <div class="modal fade" id="taskCreateModal" tabindex="-1" role="dialog"
                        aria-labelledby="taskCreateModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="taskCreateModalLabel">Create new task</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form @submit.prevent="createTask()">
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="name_task">Task Name</label>
                                            <input type="text" class="form-control" id="name_task" name="name_task"
                                                v-model="name_task" placeholder="Enter task name" required>
                                            <div class="alert alert-danger mt-1" v-if="validation.name_task">
                                                {{ validation.name_task[0] }}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="description">Description</label>
                                            <textarea class="form-control" id="description" name="description" rows="3"
                                                v-model="description" placeholder="Enter task description"></textarea>
                                            <div class="alert alert-danger mt-1" v-if="validation.description">
                                                {{ validation.description[0] }}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="priority">Priority</label>
                                            <select class="form-control" id="priority" name="priority"
                                                v-model="priority" required>
                                                <option value="">-- Select Priority --</option>
                                                <option value="1">high</option>
                                                <option value="2">medium</option>
                                                <option value="3">low</option>
                                            </select>
                                            <div class="alert alert-danger mt-1" v-if="validation.priority">
                                                {{ validation.priority[0] }}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="deadline">Deadline</label>
                                            <input type="date" v-model="deadline" class="form-control" id="deadline"
                                                name="deadline" required>
                                            <div class="alert alert-danger mt-1" v-if="validation.deadline">
                                                {{ validation.deadline[0] }}
                                            </div>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light waves-effect"
                                            data-dismiss="modal">Close</button>
                                        <button type="submit"
                                            class="btn btn-primary waves-effect waves-light">Create</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- end taskCreateModal  -->


                </div>
                <!-- end row -->

            </div>
            <!-- container -->

        </div> <!-- content -->

        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        2025 &copy; Achmad Danel by Coderthemes
                    </div>

                </div>
            </div>
        </footer>
        <!-- end Footer -->

    </div>


</template>