﻿<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import api from '../api'

const name = ref('')
const email = ref('')
const password = ref('')
const message = ref('')
const validation = ref([])

const router = useRouter()

const register = async () => {
    const data = {
        name: name.value,
        email: email.value,
        password: password.value
    }

    await api.post('/auth/registration', data)
        .then((response) => {
            validation.value = ''
            message.value = response.data.message
        }).catch((error) => {
            if (error.status === 422) {
                message.value = ''
                validation.value = error.response.data.validation
            }
        })

}

</script>


<template>

    <div class="account-pages mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card">

                        <div class="card-body p-4">

                            <div class="text-center w-75 m-auto">
                                <a href="index.html">
                                    <!-- <span><img src="assets\images\logo-dark.png" alt="" height="22"></span> -->
                                    <span>
                                        <h1 class="text-primary font-weight-bold">Sign Up</h1>
                                    </span>
                                </a>
                                <p class="text-muted mb-4 mt-3">Don't have an account? Create your own account, it takes
                                    less than a minute</p>
                            </div>

                            <form @submit.prevent="register()">

                                <div class="alert alert-success" v-if="message">
                                    {{ message }}, please login <router-link :to="{ name: 'login' }">Sign In
                                    </router-link>
                                </div>

                                <div class="form-group">
                                    <label for="fullname">Full Name</label>
                                    <input class="form-control" type="text" id="fullname" placeholder="Enter your name"
                                        required="required" v-model="name">
                                    <div class="alert alert-danger mt-1" v-if="validation.name">
                                        {{ validation.name[0] }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="emailaddress">Email address</label>
                                    <input class="form-control" type="email" id="emailaddress" required="required"
                                        placeholder="Enter your email" v-model="email">
                                    <div class="alert alert-danger mt-1" v-if="validation.email">
                                        {{ validation.email[0] }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input class="form-control" v-model="password" type="password" required=""
                                        id="password" placeholder="Enter your password">
                                    <div class="alert alert-danger mt-1" v-if="validation.password">
                                        {{ validation.password[0] }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="checkbox-signup">
                                        <label class="custom-control-label" for="checkbox-signup">I accept <a
                                                href="javascript: void(0);" class="text-dark">Terms and
                                                Conditions</a></label>
                                    </div>
                                </div>
                                <div class="form-group mb-0 text-center">
                                    <button class="btn btn-primary btn-block" type="submit"> Sign Up </button>
                                </div>

                            </form>


                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->

                    <div class="row mt-3">
                        <div class="col-12 text-center">
                            <p class="text-muted">Already have account? <router-link :to="{ name: 'login' }"
                                    class="text-muted font-weight-medium ml-1">Sign In</router-link></p>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->


    <footer class="footer footer-alt">
        2025 &copy; Achmad Danel by Coderthemes
    </footer>

</template>